### **_IMPORTANT NOTE_**
**Custom rule support was removed in SonarQube 8.9 LTS**

As a replacement, we suggest you to have a look at [ESLint](https://eslint.org/docs/developer-guide/), it provides custom rules that you can then import thanks to the [external issues](https://docs.sonarqube.org/latest/analysis/external-issues/) feature.
