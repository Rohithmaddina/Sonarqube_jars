This directory should contain file sonar-cobol-plugin-4.0.0.2525.jar (the exact version number must match
the value of property "version.sonar-cobol-plugin" in file ../pom.xml).
