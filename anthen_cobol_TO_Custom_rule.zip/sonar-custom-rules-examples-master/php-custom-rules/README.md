This example demonstrates how to write **Custom Rules** for SonarPHP.

## This example was moved to [sonar-php/php-custom-rules](https://github.com/SonarSource/sonar-php/tree/master/php-custom-rules).
