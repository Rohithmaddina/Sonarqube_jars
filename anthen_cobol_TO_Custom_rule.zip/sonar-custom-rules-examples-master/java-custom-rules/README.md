Custom Java rules
=======

The java custom-rules plugin template moved to a better place!

To learn how to write custom rules, please refer to the documentation embedded directly in the Open Source SonarSource Java Analyzer Repository, available here: [SonarSource/SonarJava](https://github.com/SonarSource/sonar-java). 

The Java Analyzer repository also contains an embedded [tutorial](https://github.com/SonarSource/sonar-java/blob/master/docs/CUSTOM_RULES_101.md), as well as a [template maven project](https://github.com/SonarSource/sonar-java/blob/master/docs/java-custom-rules-example/) to start writing custom rules fast. This template will be up-to-date with the latest releases of the Java Analyzer.
