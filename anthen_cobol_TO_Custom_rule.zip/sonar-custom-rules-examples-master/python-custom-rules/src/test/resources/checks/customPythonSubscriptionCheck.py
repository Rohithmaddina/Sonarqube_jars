class A:
  for i in foo: # Noncompliant {{For statement.}}
# ^^^
    pass
